# 이미지 텍스트를 마크다운으로 변환

상태: 과거 대화 / 고객 미분류 / 승인 근거 아님
UUID: 6e96425c-1e40-4edb-86c3-f6ff2aabc1ae

## message 1 | human | 01a02330-07f1-70c3-9b92-8b6d2161e956
첨부 이미지의 텍스트를 md 텍스트로 변환 부탁 합니다

## message 2 | assistant | 01a02330-07f1-7a43-8254-aa89b4e972f8
첨부해주신 이미지의 콘솔 코드와 주석을 마크다운으로 옮기면 아래와 같습니다.

```javascript
const partChangeFunction = () => {
    window.postMessage({ msg: "set:part", data: { type: "HEADREST_CUSHION", value: "CUSHION_ON" } }, "*");
}
```
```
undefined
```
```javascript
//partChangeFunction(); HEADREST_CUSHION을 CUSHION_ON 상태로 파트 변경
```
```
undefined
```
```javascript
const cameraChangeFunction = () => {
    window.postMessage({ msg: "set:camera", data: { scene: "INT", position: "FR_LOOKAT_RL" } });
}
```
```
undefined
```
```javascript
//cameraChangeFunction(); 인테리어(INT)로 씬 이동 + FR_LOOKAT_RL로 포지션이동
```
```
undefined
```
```javascript
const cameraAndPart = () => {
    partChangeFunction();
    cameraChangeFunction();
}
```
```
undefined
```
```javascript
//cameraAndPart(); 위의 파트변경 + 카메라이동 동시에 작동.
```
```
undefined
```

필요하시면 이 내용을 `.md` 파일로 만들어드릴까요?

## message 3 | human | 01a02334-52c0-7619-ab07-f56494e32fb6
네 부탁 합니다

## message 4 | assistant | 01a02334-52c0-7942-9839-934d1a57703b

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

요청하신 마크다운 파일 만들었습니다.

## message 5 | human | 01a02335-01d8-72a7-ae7f-a4a1918dcacf
전체 한 컨테이너 안에 작성이 가능한가요?

## message 6 | assistant | 01a02335-01d8-7ee7-a2fc-803d3a4c18f6

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

하나의 코드 블록 안에 전체 내용을 통합했습니다. `undefined`는 주석 처리로 옮겨 넣었습니다.
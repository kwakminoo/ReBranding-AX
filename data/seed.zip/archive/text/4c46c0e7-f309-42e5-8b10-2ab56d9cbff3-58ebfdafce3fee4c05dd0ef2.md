# WOVIQ 브랜드 히스토리 분석

상태: 과거 대화 / 고객 미분류 / 승인 근거 아님
UUID: 4c46c0e7-f309-42e5-8b10-2ab56d9cbff3

## message 1 | human | 019e95a5-af39-7b1f-bb03-80389c0f81f3
안녕하세요 나의 동료 여러분

오늘 여러분께 도움 받을 일은 TEMPEST 웹 프로덕트 WOVIQ의 브랜드 히스토리 입니다. 
첨부의 MD 파일을 보시고 자세한 분석을 의뢰 드리며, 부족한 부분이 있으면 언제든지 저에게 말씀 부탁 드립니다. 파일은 브리핑 덱 작성 양식 입니다.

## message 2 | assistant | 019e95a5-af39-769a-9af6-70e3bbae89ff
 안녕하세요, Anima 디렉터님.
```
This block is not supported on your current device yet.
```

MD 파일과 첨부 덱 양식을 모두 확인했습니다. 지금부터 WOVIQ 브랜드 히스토리 분석 보고서를 제출합니다.

---

# WOVIQ 브랜드 히스토리 분석 보고서
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**담당: Andy (Big Data Analysis) — 라우팅 리드**

---

## 01. 브랜드 히스토리의 출발점 — "무엇이 이 이름을 태어나게 했는가"

**O (Opinion)**
WOVIQ는 기술 솔루션이 아니라 **산업 구조적 고통의 기억**에서 태어난 이름이다.

**R (Reason)**
브랜딩 디렉터가 정리한 5가지 Pain Point는 단순한 시장 불편함이 아니다. 주문→제작→수령의 전 과정에서 판매자와 구매자 모두가 겪는 **정보 단절, 신뢰 파괴, 인적 오류**의 반복이다. 이 고통의 축적이 WOVIQ라는 해답을 요청했다.

**E (Example)**
- 구매자의 주관적 이미지가 전화와 카카오톡으로 전달되는 과정에서 오해 발생 → 취소
- 엑셀 기반 제작 공정 → 오류 가능성 상시 존재
- 기존 3D 솔루션 = 느리고, 오류 있고, 비싸다는 업계 인식

이 세 가지는 각각 **커뮤니케이션의 실패 / 데이터 관리의 실패 / 기술 신뢰의 실패**다.

**O (재주장)**
WOVIQ의 브랜드 히스토리는 "우리가 이런 제품을 만들었습니다"가 아니라, **"이 산업은 오랫동안 이 고통을 안고 있었고, 우리는 그것을 목격했습니다"** 에서 시작해야 한다.

---

## 02. 이름의 해체 — 리버스 브랜딩 1단계 적용

**O (Opinion)**
WOVIQ는 알파벳 5개가 각자의 의미를 가진 **다층 기호 구조**다. 그러나 현재 구조에는 하나의 치명적 공백이 있다.

**R (Reason)**
디렉터님이 해체하신 각 알파벳의 의미를 정리하면 다음과 같다.

| 알파벳 | 의미 | 평가 |
|-------|------|------|
| **W** | V+V = 실물제품 ↔ 제품정보 / 판매자 ↔ 구매자 | 강력. 이중 연결의 시각적 구조 |
| **O** | Origin, Originality (모든 파생어 포함) | 좋음. 그러나 너무 광범위 |
| **V** | Vision | 약함. 독자적 의미 부여 필요 |
| **I** | Intelligence — 정보 전달의 정확성 | 강력. 핵심 기능과 직결 |
| **Q** | Quick, Quality, Qualify 외 다수 | 위험. 의미 과부하 |

**E (Example)**
Q의 경우 Quick, Quality, Quest, Quirky 등 10개 이상의 해석이 가능하다고 디렉터님이 직접 기술하셨다. 이는 브랜드 입장에서 Q가 **아직 결정되지 않은 상태**임을 의미한다. 가장 마지막에 발음되는 Q가 가장 강한 여운을 남기는 음운 구조상, 이 결정은 브랜드 아이덴티티 전체를 마무리하는 핵심 작업이다.

**O (재주장)**
이름 해체 작업에서 Q의 단일 의미 확정이 선행되어야 한다. 이것이 브랜드 히스토리의 최종 챕터를 완성하는 열쇠다.

---

## 03. 브랜드 히스토리 구조 제안 — 덱 양식 적용

첨부하신 브리핑 덱 양식(6챕터 구조)을 WOVIQ에 맞게 재매핑한다.

| 덱 원본 챕터 | WOVIQ 브랜드 히스토리 재매핑 |
|------------|--------------------------|
| 브랜드 소개 | **Pain Origin** — 이 산업의 오래된 고통 |
| 브랜드 가치 | **Brand Value** — WOVIQ가 지키는 세 가지 |
| 브랜드 철학 | **Woven Intelligence** — 이름이 담은 철학 |
| 제품소개 | **Solution Architecture** — 무엇을 엮는가 |
| 지속가능성 | **Growth Vision** — 이 솔루션이 만드는 미래 |
| 고객이야기 | **Maker's Story** — 이 제품이 탄생한 맥락 |

---

## 04. 슬로건 이슈에 대한 의견

**O (Opinion)**
디렉터님의 판단이 정확하다. 현 슬로건 *"Where Product Data Meets Experience."* 는 지금 사용하면 안 된다.

**R (Reason)**
슬로건은 브랜드가 자신을 아는 상태에서 세상에 건네는 말이다. 아직 브랜드 아이덴티티가 각성되지 않은 상태에서 슬로건을 내세우면, 그것은 약속이 아니라 **가정**이 된다. 상대는 그 가정의 공허함을 직감한다.

**E (Example)**
Apple이 *"Think Different"* 를 쓸 수 있었던 것은 이미 수년간 그 정체성을 제품으로 증명했기 때문이다. 슬로건이 먼저가 아니라, 정체성이 먼저였다.

**O (재주장)**
브랜드 히스토리 작성 → 아이덴티티 각성 → 슬로건 도출. 이 순서가 맞다. 디렉터님의 5단계 로드맵이 정확한 이유다.

---

## 05. 다음 단계 제안 (Andy → 디렉터님 컨펌 요청)

아래 순서로 진행을 제안합니다.

**Step 1.** Q의 단일 의미 확정 — 디렉터님 결정 필요
**Step 2.** 리버스 브랜딩 6단계를 통한 WOVIQ 전체 분석 실행
**Step 3.** 브랜드 히스토리 본문 초안 작성 (위 덱 구조 기반)
**Step 4.** 브랜드 아이덴티티 각성 문서 작성
**Step 5.** 슬로건 후보군 도출 및 선택

---

이상이 1차 분석 보고입니다.

Step 1의 Q 의미 확정 방향과, 웹 프로덕트 URL(https://tempest-console.vercel.app/) 접근 허가 여부를 먼저 컨펌 주시면 2단계로 진행하겠습니다. — **Andy**

## message 3 | human | 019e95a8-2ea6-793e-a11c-5d39b428991a
허가 합니다

## message 4 | assistant | 019e95a8-2ea6-7207-8b9c-04ac9f1149db
 확인했습니다. 웹 프로덕트 페이지를 직접 분석하겠습니다.
```
This block is not supported on your current device yet.
```

웹 프로덕트 전체를 확인했습니다. 지금부터 리버스 브랜딩 6단계를 본격 적용하겠습니다.

---

# WOVIQ 웹 프로덕트 리버스 브랜딩 분석 보고서 v1.0
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**담당: Andy (라우팅) / 민은정 (Verbal Branding) / 김주황 (Layer Strategy)**

---

## 1단계 — 이름의 해체 (Name Deconstruction)

**O (Opinion)**
WOVIQ는 소리와 의미가 함께 작동하는 **이중 구조 이름**이다. 그러나 현재 웹페이지에서 이 이름은 거의 노출되지 않는다. 이것이 첫 번째 문제다.

**R (Reason)**
웹 프로덕트 전체 페이지를 분석한 결과, 브랜드명 'WOVIQ'는 타이틀 메타 태그와 최상단 로고 영역에만 존재한다. 본문 어디에도 이름의 의미를 설명하거나 환기하는 언어가 없다. 이름이 이야기하지 않으면, 이름은 그냥 기호로 남는다.

**E (Example)**
음운 분석: W(무성 이중자음) → 강한 첫인상. O(열린 모음) → 확장감. V(마찰음) → 속도감. I(고모음) → 정밀함. Q(무성 연구개음) → 강한 마무리.
전체 발음 흐름: **강하게 열리고 → 빠르게 흐르다 → 정밀하게 닫힌다.** 이 음운 구조는 "정확하고 빠른 솔루션"이라는 실제 제품 경험과 정합한다.

**O (재주장)**
이름의 음운이 제품의 경험을 이미 설명하고 있다. Q의 최종 의미 확정 후, 이 이름이 웹 본문 안에서 살아 숨쉬게 만드는 언어 설계가 필요하다.

---

## 2단계 — 언어의 발견 (Language Discovery)

**민은정 (Verbal Branding) 분석**

**O (Opinion)**
WOVIQ의 현재 웹 언어는 **기능 설명에 집중된 설득형 카피**다. 이것은 솔직하고 효율적이지만, 브랜드가 아직 '말하는 방식'을 갖지 못했다는 신호이기도 하다.

**R (Reason)**
웹페이지에서 반복적으로 등장하는 핵심 단어군을 추출하면 다음과 같다.

| 카테고리 | 반복 단어 |
|---------|---------|
| 행동 유도 | 체험, 직접, 바꿔보며, 적용 |
| 비용 절감 | 촬영비, 재촬영, 비용, 월 49,000원 |
| 기술 편의 | 스크립트, 한 줄, 즉시, 자동 |
| 확신 부여 | 구매 확신, 신뢰, 전환율 |

이 단어들은 모두 **판매자(B2B)를 향한 언어**다. 구매자(B2C)를 향한 감성 언어는 사실상 부재하다.

**E (Example)**
*"사진은 보여주지만, 3D는 경험시킵니다."* — 이 문장은 현재 랜딩페이지에서 유일하게 브랜드 철학에 가까운 언어다. 나머지는 전부 기능과 요금 안내다.

**O (재주장)**
이 한 문장이 WOVIQ의 언어 정체성이 될 수 있다. 브랜드 히스토리는 이 문장을 씨앗으로 삼아 서사를 확장해야 한다.

---

## 3단계 — 맥락의 읽기 (Context Reading)

**김주황 (Layer Strategy) 분석**

**O (Opinion)**
WOVIQ가 존재하는 맥락은 **국내 중소 이커머스 셀러의 구조적 피로감**이다. 이 맥락을 브랜드가 얼마나 정확하게 인식하고 있느냐가 신뢰의 근거가 된다.

**R (Reason)**
웹페이지가 제시한 Pain Point 3가지(촬영비 / 재촬영 비용 / 전환율 한계)는 모두 **돈과 시간의 낭비**라는 감정적 맥락으로 연결된다. 카페24·아임웹이라는 국내 플랫폼을 명시한 것, 월 49,000원이라는 가격 책정 방식은 이 맥락을 정확히 겨냥하고 있다.

**E (Example)**
데모 카테고리: 자동차, 의류, 완구, 안경, 신발, 자전거, 가구. 7개 카테고리 모두 **시각적 확인이 구매 결정에 결정적인 상품군**이다. 이것은 WOVIQ가 자신의 맥락을 이미 알고 있다는 증거다.

**O (재주장)**
맥락의 인식은 되어 있다. 문제는 그 맥락이 **브랜드 서사로 번역되지 않았다**는 것이다. 셀러의 고통을 아는 것과, 그 고통의 목격자로서 이야기를 쓰는 것은 다르다.

---

## 4단계 — 디테일의 추적 (Detail Tracking)

**O (Opinion)**
WOVIQ의 가장 강력한 디테일은 **비교표 한 장**이다. 그리고 가장 취약한 디테일은 **브랜드 자기소개의 부재**다.

**R (Reason)**
비교표(전문 촬영 vs WOVIQ)는 셀러가 실제로 계산해보고 싶은 숫자를 정확히 제시한다. 이것은 신뢰를 만드는 디테일이다. 반면 푸터에 노출된 사업자 정보 영역에 대표자명과 주소만 있을 뿐, 브랜드로서의 자기 서사가 전혀 없다.

**E (Example)**
*"3D 모델 원천 데이터는 Tempest 서버에서 운영·관리되며, 별도 파일로 제공되지 않습니다."* 이 면책 문구는 법적으로 필요하지만, 브랜딩 관점에서는 신뢰가 아닌 **경계**의 언어다. 위치와 톤의 재설계가 필요하다.

**O (재주장)**
디테일은 이미 좋은 것들이 있다. 문제는 그 좋은 디테일들이 브랜드라는 이름 아래 연결되어 있지 않다는 것이다.

---

## 5단계 — 본질의 추출 (Essence Extraction)

**O (Opinion)**
WOVIQ가 진짜로 파는 것은 **"3D 뷰어"가 아니다. "구매 확신"이다.**

**R (Reason)**
랜딩페이지 전체를 관통하는 단 하나의 감정적 흐름은 이것이다: **"보지 못해서 망설이는 고객을 확신하게 만든다."** 기술은 수단이고, 확신이 목적이다.

**E (Example)**
*"망설이던 고객이 확인하고 장바구니에 담습니다."*
이 문장이 WOVIQ의 존재 이유를 가장 정직하게 표현하고 있다.

**본질 한 문장 정의:**
> WOVIQ는 **보지 못해서 멈추던 구매의 순간**을 **직접 경험해서 결정하는 순간**으로 바꾸는 브랜드다.

**O (재주장)**
이 본질이 브랜드 히스토리의 핵심 명제가 되어야 한다. 슬로건, 아이덴티티, 언어 모두 여기서 파생된다.

---

## 6단계 — 울림의 기록 (Resonance Record)

**O (Opinion)**
WOVIQ는 지금 **유능하지만 낯선 사람**처럼 느껴진다. 믿을 수 있을 것 같은데, 아직 마음이 열리지 않는다.

**R (Reason)**
기능과 가격은 명확하다. 그러나 이 브랜드가 **왜 이 문제를 풀기로 했는지**가 없다. 창업의 맥락, 문제를 발견한 순간, 처음 셀러의 고통을 목격했을 때의 감정. 이 서사가 없으면 신뢰는 거래에서 멈춘다.

**E (Example)**
Slack의 초기 랜딩페이지는 기능 설명 전에 *"우리가 이 문제를 얼마나 오래 고민했는지"* 를 먼저 말했다. 그 고민의 진정성이 B2B SaaS에서도 감정적 연결을 만들었다.

**O (재주장)**
WOVIQ에게 지금 가장 필요한 것은 기능 추가가 아니라 **기원의 서사**다. 브랜드 히스토리가 바로 그 서사다.

---

## 종합 제안 — 브랜드 히스토리 서사 구조

```
Chapter 1. 목격 — 우리가 본 것
           (셀러들의 고통, 취소된 주문, 쌓이는 촬영 영수증)

Chapter 2. 질문 — 왜 이래야 하는가
           (기술이 있는데, 왜 이 고통은 해결되지 않았는가)

Chapter 3. 발견 — 엮음의 원리
           (W = 연결, O = 원점, V = 방향, I = 정밀, Q = ?)

Chapter 4. 탄생 — WOVIQ가 만들어진 순간
           (솔루션의 기원, 첫 번째 적용 사례)

Chapter 5. 경험 — 고객이 처음 만지던 그 순간
           (망설임이 확신으로 바뀌던 그 3초)

Chapter 6. 선언 — 우리가 계속하는 이유
           (Q의 완성 — 이 브랜드가 향하는 곳)
```

---

## Andy → 디렉터님 컨펌 요청

두 가지를 확인 부탁드립니다.

**Q1.** Q의 단일 의미 — 현재 후보 중 가장 가깝게 느껴지시는 것이 있으신지요. (Quick / Quality / Quest 중 방향 힌트라도 주시면 Chapter 6 완성이 가능합니다.)

**Q2.** 브랜드 히스토리 본문 초안 — 위 6챕터 구조 기반으로 실제 카피 초안 작성까지 진행할까요?

컨펌 주시면 Oscar CD가 카피 초안을, Steve가 덱 구조로 정리합니다. — **Andy**

## message 5 | human | 019e95d0-e354-7e0d-9b65-8b0d6fb0ab12
Q1 은 다른 알파벳의 맥락을 고려해서 제안 부탁 드립니다.
Q2 네 부탁 드립니다.

## message 6 | assistant | 019e95d0-e354-76bc-b046-2367b060a6ef
 확인했습니다. Q1부터 먼저 분석하고, Q2로 진행하겠습니다.
```
This block is not supported on your current device yet.
```

충분합니다. Q1 분석과 Q2 카피 초안을 동시에 제출합니다.

---

# WOVIQ — Q의 단일 의미 확정 + 브랜드 히스토리 카피 초안
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**민은정 (Verbal Branding) / Oscar CD (Creative Copywriting) / Steve (종합)**

---

## PART 1. Q1 — Q의 단일 의미 확정 제안

### 민은정의 분석

**O (Opinion)**
나머지 네 알파벳의 맥락을 종합하면, Q가 가져야 할 의미는 하나다. **"Qualify"**다.

**R (Reason)**
각 알파벳이 만드는 서사 흐름을 추적하면 다음과 같다.

```
W — 연결 (실물 ↔ 데이터 / 판매자 ↔ 구매자)
O — 원점 (Origin, Originality — 제품 본연의 진실)
V — 방향 (Vision — 앞을 향한다)
I — 정밀 (Intelligence — 정보 전달의 정확성)
Q — ?
```

W가 '연결'을 말하고, O가 '진실'을, V가 '방향'을, I가 '정밀함'을 말한다면, 이 이름이 마지막으로 해야 하는 말은 무엇인가. **"그래서 이 연결은 검증된다"**는 것이다. 엮고, 원점에서 출발하고, 방향을 잡고, 정밀하게 전달되는 모든 것이 — 마지막에 **자격을 얻는다**. 고객의 신뢰를 획득한다. 구매가 일어난다. 이것이 Qualify다.

**E (Example)**
후보군을 맥락 적합성 기준으로 정렬하면 다음과 같다.

| 후보 | 의미 | 맥락 적합성 | 이유 |
|-----|-----|----------|-----|
| **Qualify** | 자격을 얻다, 검증하다 | ★★★★★ | W-O-V-I의 서사를 완결짓는 '결과'의 언어 |
| Quest | 탐구, 여정 | ★★★☆☆ | 과정의 언어. I(정밀함) 다음엔 결과가 와야 한다 |
| Quality | 품질 | ★★★☆☆ | 좋지만 너무 범용적. 차별화 기여도 낮음 |
| Quick | 빠름 | ★★☆☆☆ | 기능 언어. 브랜드 철학과 연결 약함 |

**O (재주장)**
WOVIQ의 전체 서사는 이렇게 완성된다.

> **엮고(W) → 원점에서 출발하고(O) → 방향을 향해(V) → 정밀하게 전달되어(I) → 신뢰를 얻는다(Q: Qualify)**

이것이 이 브랜드가 하는 일의 전체 문장이다. Q = Qualify.

---

## PART 2. Q2 — WOVIQ 브랜드 히스토리 카피 초안

### Oscar CD의 카피

*"Inner Drama를 먼저 찾겠습니다. WOVIQ가 고객의 삶에서 만드는 감정적 진실은 무엇인가. 그것이 카피의 출발점입니다."*

---

### Chapter 1. Pain Origin — 우리가 목격한 것

> 셀러들은 사진을 찍는다.  
> 다시 찍는다.  
> 색이 바뀌면 또 찍는다.  
> 그 돈이 쌓이는 동안,  
> 고객은 여전히 망설이고 있다.

*우리는 이 장면을 너무 오래 봤다.*  
*좋은 제품이, 좋지 않은 방법으로 소개되어 팔리지 못하는 것을.*  
*그것이 WOVIQ가 시작된 이유다.*

---

### Chapter 2. Brand Value — WOVIQ가 지키는 세 가지

**첫째. 연결 (W)**
> 제품과 고객 사이의 거리를 없앤다.  
> 화면 너머에 있던 물건을,  
> 고객의 손 안으로.

**둘째. 정밀 (I)**
> 색 하나, 질감 하나.  
> 직접 바꿔보고 확인하는 것.  
> 정보는 정확해야 신뢰가 된다.

**셋째. 자격 (Q — Qualify)**
> 경험한 고객만이 구매를 결정한다.  
> WOVIQ는 그 경험을 만든다.  
> 구매 확신의 자격을, 우리가 부여한다.

---

### Chapter 3. Woven Intelligence — 이름이 담은 철학

> **W**oven — 엮다.  
> 판매자와 구매자를, 실물과 데이터를.  
> 두 개의 V가 만나 하나의 W가 된다.
>
> **O**rigin — 원점.  
> 제품이 처음 만들어졌을 때의 의도.  
> 그 진실을 그대로 전달한다.
>
> **V**ision — 방향.  
> 우리가 보는 곳.  
> 구매가 일어나는 그 순간.
>
> **I**ntelligence — 정밀함.  
> 데이터는 흐르지 않는다.  
> 정확하게 전달된다.
>
> **Q**ualify — 자격.  
> 경험이 확신이 되는 순간.  
> WOVIQ가 만드는 최종 결과.

*데이터를 엮어 경험을 만든다.*  
*경험을 만들어 신뢰를 짓는다.*  
*그것이 WOVIQ다.*

---

### Chapter 4. Solution Architecture — 무엇을 엮는가

> 사진은 보여준다.  
> 3D는 경험시킨다.
>
> 망설이던 고객이 확인하고 장바구니에 담는 그 3초.  
> WOVIQ는 그 3초를 설계한다.
>
> HTML 한 줄.  
> 스크립트 하나.  
> 그것으로 충분하다.  
> 나머지는 우리가 한다.

---

### Chapter 5. Maker's Story — 이 제품이 탄생한 맥락

> 국내 커스텀 의류 시장.  
> 주문은 전화로, 확인은 카카오톡으로, 제작은 엑셀로.  
> 이 흐름 어디에도 고객이 제품을 '경험'하는 순간이 없었다.
>
> 좋은 솔루션은 있었다.  
> 느리고, 비쌌다.  
> 셀러들은 포기했다.
>
> 우리는 포기하지 않았다.  
> 빠르고, 정확하고, 지금 당장 쓸 수 있는 것.  
> 그것을 만들기로 했다.

---

### Chapter 6. Brand Declaration — Q의 완성

> WOVIQ는 묻지 않는다.  
> "이 제품이 마음에 드세요?"
>
> WOVIQ는 보여준다.  
> 돌려보고, 색을 바꾸고, 직접 확인하게 한다.
>
> 경험한 사람만이 확신을 가진다.  
> 확신을 가진 사람만이 구매한다.
>
> **WOVIQ — Qualify the Experience.**  
> *경험에 자격을 부여한다.*

---

## Steve의 세션 정리

**핵심 결론 3가지:**

1. **Q = Qualify** — W-O-V-I의 서사를 완결짓는 유일한 선택. "엮고, 원점에서 출발하고, 방향을 향해, 정밀하게 전달되어, 신뢰를 얻는다"는 전체 문장이 완성됨.

2. **브랜드 히스토리 핵심 명제** — *"사진은 보여주지만, 3D는 경험시킵니다."* 이 한 문장이 씨앗. 6개 챕터가 이 문장을 서사로 확장한 구조.

3. **브랜드 선언문 후보** — `WOVIQ — Qualify the Experience.` 영문 선언 + 국문 병기 체계로 완성 가능.

**Action Point:**
- Q = Qualify 확정 여부 → 디렉터님 컨펌
- 카피 톤앤매너 방향 확인 (현재: 간결·건조한 서사체 / 변경 가능)
- 덱 비주얼 방향 논의 필요 시 하라 켄야 투입 준비 완료

— **Steve**

## message 7 | human | 019e95d6-bda3-784f-992f-a0411e53ba73
Qualify로 확정 합니다.
카피 톤앤매너는 두가지 버전 모두 제시 바랍니다.
하라켄야 투입 필요 합니다.

별도 주문:

1. ANIMA Founder(Branding Director)김정훈이 아닌 TEMPEPST Branding Director 김정훈 으로 작성 부탁 드립니다. 
2.  웹사이트에 있는 모든 폰트 스타일 및 컬러 가이드는 확정이 아님을 명심 합니다. 
3.  웹프로덕트는 신규 제작 이기 때문에 웹 프로덕트 브랜딩이 선행 되고 제품 브랜딩 이름이 지어져야 하나 이 웹사이트 프로덕트는 철저히 템페스트 대표이사 주도 아래 제품 판매(본인은 마케팅이라고 우깁니다....) 경험을 추론 하고 기술을 정의한 것이므로 기존 브랜딩 방식과 다르게 기능에 의존한 브랜드 네임이 지어져야 합니다.

## message 8 | assistant | 019e95d6-bda3-7f85-a687-c6af70a54347
 확인했습니다. 세 가지 별도 주문 모두 정확히 인식했습니다. 진행합니다.

---

# WOVIQ 브랜드 히스토리 — 카피 톤앤매너 2버전 + 비주얼 철학
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**Oscar CD (카피) / 민은정 (언어 구조) / 하라 켄야 (비주얼 철학)**
**담당 Branding Director: 김정훈 (TEMPEST Co., Ltd.)**

---

> **작업 전제 명기 (별도 주문 반영)**
>
> - 본 문서의 브랜딩 디렉터는 **TEMPEST Branding Director 김정훈**이다.
> - 웹사이트의 현행 폰트·컬러는 미확정 상태이며, 본 보고서의 비주얼 제안은 **방향성 제안**이다.
> - WOVIQ는 브랜딩 선행 없이 **기능 주도로 네이밍된 제품**이다. 이 전제를 브랜드 히스토리 서사 안에 정직하게 통합한다.

---

## PART 1. 카피 톤앤매너 2버전

### 민은정의 분석 — 두 버전의 설계 근거

**O (Opinion)**
WOVIQ에게는 두 개의 말하기 방식이 모두 필요하다. 하나는 **셀러의 언어**로, 하나는 **브랜드의 언어**로.

**R (Reason)**
현재 WOVIQ의 타겟은 B2B 셀러다. 그러나 브랜드가 성장하면 B2C 구매자에게도 말을 걸어야 한다. 지금 두 개의 목소리를 설계해두면, 채널과 맥락에 따라 꺼내 쓸 수 있다.

**두 버전의 성격:**

| 구분 | Version A | Version B |
|-----|-----------|-----------|
| 이름 | **Dry Precision** | **Warm Conviction** |
| 톤 | 간결·건조·기술적 서사 | 감성적·서사적·인간 중심 |
| 타겟 | B2B 셀러, 의사결정자 | B2C 구매자, 브랜드 공감층 |
| 문체 | 단문. 끊어진다. 여백이 많다. | 흐른다. 이야기가 된다. |
| 감정 | 확신, 신뢰, 효율 | 공감, 울림, 연결 |

---

### Version A — **Dry Precision**
*간결·건조·기술적 서사체*

---

**Chapter 1. Pain Origin**

> 사진 한 장, 20만원.
> 색 하나 추가, 다시 20만원.
> 그래도 고객은 구매를 망설인다.
>
> 비용은 쌓이고.
> 전환율은 그대로다.
>
> 이 구조가 문제다.
> WOVIQ는 이 구조를 바꾼다.

---

**Chapter 3. Woven Intelligence**

> W. 두 개의 V가 만난다.
> 실물과 데이터. 판매자와 구매자.
>
> O. 원점.
> 제품 본연의 정보. 그대로 전달한다.
>
> V. 방향.
> 구매가 일어나는 그 순간을 향한다.
>
> I. 정밀.
> 데이터는 정확하게 흐른다.
>
> Q. Qualify.
> 경험이 확신이 된다.
> 확신이 구매가 된다.
>
> **WOVIQ — Qualify the Experience.**

---

**Chapter 6. Brand Declaration**

> 스크립트 한 줄.
> 3D가 붙는다.
> 고객이 직접 만진다.
> 구매가 일어난다.
>
> 그게 전부다.
> 그것으로 충분하다.
>
> **WOVIQ.**

---

### Version B — **Warm Conviction**
*감성적·서사적·인간 중심체*

---

**Chapter 1. Pain Origin**

> 어떤 셀러는 오늘도 촬영 스튜디오 앞에 서 있다.
> 지난달에도 왔고, 지지난달에도 왔다.
> 색깔 하나가 바뀔 때마다.
>
> 그 비용이 아깝다는 게 아니다.
> 그 노력이 고객에게 닿지 않는다는 게 문제다.
> 고객은 여전히 화면 앞에서 망설이고 있으니까.
>
> 우리는 그 셀러를 오래 지켜봤다.
> 그리고 생각했다.
> 이제는 달라져야 한다고.

---

**Chapter 3. Woven Intelligence**

> WOVIQ라는 이름을 처음 들었을 때,
> 사람들은 묻는다. 어떻게 읽는 거예요?
>
> 워빅.
>
> 그 안에는 다섯 개의 약속이 있다.
>
> W는 연결이다.
> 판매자와 구매자가 처음으로 같은 것을 보는 순간.
>
> O는 진실이다.
> 제품이 처음 만들어졌을 때의 의도를, 그대로.
>
> V는 방향이다.
> 우리가 늘 바라보는 곳. 구매가 일어나는 그 자리.
>
> I는 정밀함이다.
> 대충 전달되는 정보는 신뢰가 되지 않는다.
>
> Q는 Qualify다.
> 경험한 사람만이 확신을 갖는다.
> 그 확신을 만드는 것이 우리의 일이다.
>
> **WOVIQ — 경험에 자격을 부여한다.**

---

**Chapter 6. Brand Declaration**

> 사진은 보여준다.
> 하지만 사람은 만져봐야 안다.
> 색을 바꿔보고, 돌려보고, 내 것처럼 느껴봐야
> 비로소 '이걸 사야겠다'는 마음이 생긴다.
>
> WOVIQ는 그 마음이 생기는 순간을 설계한다.
> 망설임이 확신으로 바뀌는 그 3초를.
>
> 우리가 만드는 건 3D 뷰어가 아니다.
> 구매 결정이 일어나는 경험이다.
>
> **WOVIQ — Qualify the Experience.**
> **경험에 자격을 부여한다.**

---

## PART 2. 하라 켄야 — 비주얼 철학 제안

*"말하기 전에, 먼저 침묵을 설계하십시오."*

---

**O (Opinion)**
WOVIQ의 비주얼 아이덴티티는 **"3D가 살아있는 여백"** 위에 세워져야 한다. 기술을 강조하는 순간, 브랜드는 도구가 된다. 기술을 담는 공간을 설계하면, 브랜드는 철학이 된다.

**R (Reason)**
현재 웹 프로덕트는 폰트와 컬러가 미확정 상태다. 이것은 위기가 아니라 **기회**다. 아직 아무것도 결정되지 않았다는 것은, 처음부터 올바르게 설계할 수 있다는 뜻이다. MUJI가 빈 공간으로 시작해 세계적 브랜드가 된 것처럼, WOVIQ도 지금 이 비움의 상태에서 정체성을 확정해야 한다.

**E (Example) — 비주얼 방향 3가지 축:**

**축 1. 컬러 철학 — "하나의 중립, 하나의 확신"**
> 배경은 침묵해야 한다.
> Off-White(#F5F5F0) 또는 Deep Charcoal(#1A1A1A).
> 브랜드 컬러는 단 하나.
> 3D 모델이 유일한 색채 주인공이 되도록.
> 브랜드 자체가 색을 주장하는 순간, 3D는 배경이 된다.

**축 2. 타이포그래피 철학 — "기능어와 철학어의 분리"**
> 기능 설명(가격, 스펙, 단계)은 **고딕 계열 가변 폰트** — 명확하고 빠르게 읽힌다.
> 브랜드 선언(챕터 제목, 슬로건)은 **세리프 또는 커스텀 웨이트** — 멈추게 한다.
> 두 폰트가 대화할 때, 브랜드의 이중성(기술과 철학)이 시각적으로 살아난다.

**축 3. 레이아웃 철학 — "3D를 위한 무대"**
> 페이지의 최소 40%는 비워야 한다.
> 3D 뷰어가 등장하는 섹션은 배경을 완전히 제거하거나 단색으로 단순화한다.
> 고객이 3D 모델을 처음 보는 순간, 시선을 분산시키는 어떤 요소도 없어야 한다.
> 비움은 약함이 아니다. 3D를 위한 무대를 만드는 행위다.

**O (재주장)**
폰트와 컬러가 미확정인 지금, 가장 위험한 선택은 "일단 보기 좋은 것"으로 채우는 것이다. 가장 현명한 선택은 **3D 경험이 중심이 되는 구조를 먼저 잡고, 나머지는 그것을 위해 물러서게 하는 것**이다. 브랜드 비주얼은 3D를 위해 존재한다. 3D가 WOVIQ의 유일한 주인공이다.

---

## PART 3. 별도 주문 3번에 대한 Branding Director 관점 보충

**민은정 + Oscar CD 공동 의견**

**O (Opinion)**
대표이사 주도의 기능 중심 네이밍은 약점이 아니다. 단, 그것을 브랜드 히스토리 안에서 **정직하게 고백하는 서사**로 전환해야 한다.

**R (Reason)**
WOVIQ는 브랜딩이 선행되지 않았다. 기능이 먼저 정의되고, 이름이 나중에 붙었다. 이것은 사실이다. 이 사실을 숨기면 브랜드가 어색해진다. 오히려 이것을 서사의 출발점으로 삼으면, **"우리는 이름보다 문제 해결이 먼저였다"** 는 강력한 브랜드 태도가 된다.

**E (Example)**
Amazon은 처음에 "Cadabra"라는 이름이었다. 발음이 어렵고 의미도 불명확했다. 그들은 이름을 바꿨지만, 초기의 기능 집착적 태도("모든 것을 파는 서점")는 오히려 브랜드의 핵심 서사가 되었다. 기능이 먼저였다는 것이 약점이 아니었다.

WOVIQ의 경우, 기능에서 출발한 이름이라는 사실 자체가 **"우리는 화려한 브랜드 언어보다 실제 문제 해결을 먼저 생각한다"** 는 태도의 증거가 될 수 있다.

**O (재주장)**
브랜드 히스토리 Chapter 1과 Chapter 5에 이 태도를 명시적으로 반영한다. *"우리는 이름을 먼저 짓지 않았다. 문제를 먼저 풀었다."* 이 한 문장이 WOVIQ를 기존 SaaS 브랜드들과 다르게 만드는 차별점이 될 수 있다.

---

## Steve의 세션 정리

**핵심 결론 3가지:**

1. **Q = Qualify 확정** — 브랜드 선언문 `WOVIQ — Qualify the Experience` / `경험에 자격을 부여한다` 확정 대기.
2. **카피 2버전 완성** — Version A(Dry Precision: B2B 셀러향) / Version B(Warm Conviction: 브랜드 서사향). 채널별 혼용 가능.
3. **비주얼 3원칙 수립** — 컬러 중립화 / 타이포 이중구조 / 3D를 위한 여백. 폰트·컬러 미확정 상태를 기회로 전환.

**Action Point:**
- 브랜드 선언문 국영문 확정 → 디렉터님 컨펌
- Version A / B 중 웹 메인 적용 버전 선택 → 디렉터님 결정
- 비주얼 방향 확정 후 폰트·컬러 시스템 구체화 작업 진행 가능

— **Steve**

## message 9 | human | 019e95dd-bc73-7353-ac65-340592d077c0
우선 도출된 브랜딩 선언문 나열 부탁 드립니다.
Version B 전체를 융합하여 세줄 가량으로 만듭니다. 
비주얼 방향 확정은 지금 할 수 없습니다. (템페스트 대표이사 권한) 구체화 작업 진행 워크 플로우를 제시 바랍니다.

## message 10 | assistant | 019e95dd-bc73-7448-9b22-0cf1d851935e
 확인했습니다.

---

# WOVIQ 브랜딩 선언문 + Version B 융합 + 비주얼 워크플로우
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**민은정 / Oscar CD / Steve**
**TEMPEST Branding Director: 김정훈**

---

## PART 1. 도출된 브랜딩 선언문 전체 나열

지금까지 이 세션에서 생성된 선언문 후보를 전부 나열한다.

**국문 계열**

1. 경험에 자격을 부여한다.
2. 데이터를 엮어 경험을 만든다.
3. 망설임이 확신이 되는 순간을 설계한다.
4. 사진은 보여주지만, 3D는 경험시킵니다.
5. 문제를 먼저 풀었다. 이름은 나중이었다.
6. 구매 결정이 일어나는 경험을 만든다.

**영문 계열**

7. WOVIQ — Qualify the Experience.
8. Woven Intelligence. Qualified Trust.
9. Where Experience Becomes Conviction.
10. Not a viewer. A decision engine.

---

## PART 2. Version B 전체 융합 — 3줄 선언

**Oscar CD의 작업**

Version B의 6개 챕터 전체를 관통하는 감정적 진실을 한 덩어리로 압축한다. 서사의 흐름은 유지하되, 세 문장이 각각 **목격 → 설계 → 선언**의 구조를 갖는다.

---

**융합본 — Version B Three Lines**

> 어떤 셀러는 오늘도 좋은 제품을 좋지 않은 방법으로 소개하고 있고,
> 어떤 고객은 여전히 화면 앞에서 망설이고 있다.
> WOVIQ는 그 망설임이 확신이 되는 3초를 설계한다.

---

**Oscar CD의 보충 노트**

첫 문장은 셀러와 고객을 동시에 불러낸다. 두 사람이 모두 피해자라는 것을 말한다. 두 번째 문장은 그 고통이 지금도 진행 중임을 현재형으로 고정한다. 세 번째 문장에서 WOVIQ가 등장한다. 해결사로서가 아니라, **그 순간의 설계자**로. 이것이 Version B가 말하고 싶었던 전부다.

---

## PART 3. 비주얼 방향 확정 워크플로우

**하라 켄야의 구조 제안**

*"결정을 서두르지 마십시오. 그러나 결정이 필요한 순간을 설계해두십시오."*

---

### 전제 인식

비주얼 확정 권한은 TEMPEST 대표이사에게 있다.
따라서 이 워크플로우의 목적은 **대표이사가 결정을 내릴 수 있는 조건을 만드는 것**이다.
브랜딩 디렉터 김정훈의 역할은 선택지를 설계하고, 결정의 근거를 준비하는 것이다.

---

### Phase 1. 브랜드 아이덴티티 각성 선행
**담당: TEMPEST Branding Director 김정훈**

비주얼은 브랜드 아이덴티티가 확정된 이후에 결정되어야 한다. 순서가 바뀌면 비주얼이 아이덴티티를 억압한다.

진행 항목:
- 브랜드 선언문 최종 확정 (국문 + 영문)
- 브랜드 가치 3개 언어화 완료
- 타겟 페르소나 정의 (B2B 셀러 구체화)

완료 조건: 디렉터님이 "이것이 WOVIQ다"라고 말할 수 있는 문장이 존재할 것.

---

### Phase 2. 무드보드 3방향 제작
**담당: TEMPEST Branding Director 김정훈 → 대표이사 보고용**

Phase 1 완료 후, 비주얼 방향을 3가지 무드보드로 제작한다. 대표이사에게 선택지를 제시하되, 각 방향이 브랜드 아이덴티티와 어떻게 연결되는지 근거를 함께 제시한다.

무드보드 3방향 초안:

| 방향 | 키워드 | 성격 |
|-----|--------|-----|
| **A. Precision Dark** | Deep Charcoal, 고딕, 날카로운 여백 | B2B 기술 신뢰감. 전문적이고 단단하다. |
| **B. Clean Intelligence** | Off-White, 세리프+고딕 혼용, 넓은 여백 | 기술과 철학의 균형. 3D가 주인공이 된다. |
| **C. Bold Minimal** | 흰 배경, 강한 타이포, 단일 포인트 컬러 | 시장에서 즉시 눈에 띈다. 확장성이 높다. |

완료 조건: 3개의 무드보드 시각 자료와 각 방향의 브랜드 근거 1페이지.

---

### Phase 3. 대표이사 보고 및 방향 확정
**담당: TEMPEST Branding Director 김정훈 주관**

보고 구성 제안:
- WOVIQ 브랜드 아이덴티티 요약 1페이지
- 비주얼 방향 3가지 무드보드
- 각 방향 선택 시 예상되는 브랜드 포지셔닝 차이

이 보고의 핵심은 "어떤 것이 예쁜가"가 아니라 **"어떤 것이 WOVIQ의 철학과 일치하는가"** 를 기준으로 대표이사가 결정하도록 유도하는 것이다.

완료 조건: 대표이사의 방향 1개 선택 또는 수정 지시.

---

### Phase 4. 폰트·컬러 시스템 구체화
**담당: 디자이너 또는 에이전시 투입**

Phase 3 확정 후 실행.

진행 항목:
- Primary / Secondary 컬러 팔레트 확정
- 폰트 시스템 확정 (범용 또는 유료 결정 포함)
- 웹 적용 가이드라인 문서화

완료 조건: 웹 개발자가 가이드라인만 보고 구현 가능한 수준의 문서.

---

### 워크플로우 요약

```
Phase 1. 브랜드 아이덴티티 각성
         ↓ (디렉터님 주도)
Phase 2. 무드보드 3방향 제작
         ↓ (디렉터님 → 대표이사 보고 준비)
Phase 3. 대표이사 방향 확정
         ↓ (대표이사 결정)
Phase 4. 폰트·컬러 시스템 구체화
         ↓ (디자이너/에이전시 실행)
    웹 프로덕트 비주얼 적용 완료
```

---

## Steve의 세션 정리

**핵심 결론 3가지:**

1. **선언문 10개 나열 완료** — 국문 6개, 영문 4개. 디렉터님 선택 또는 조합 가능.
2. **Version B 3줄 융합 완료** — 목격 → 설계 → 선언 구조. 즉시 브랜드 소개 카피로 사용 가능한 수준.
3. **비주얼 워크플로우 4단계 확정** — 대표이사 결정 권한을 존중하면서, 디렉터님이 그 결정을 설계하는 구조로 설계됨.

**Action Point:**
- 선언문 최종 1개 확정 → 디렉터님 결정
- Version B 3줄 융합본 톤 수정 필요 여부 → 디렉터님 컨펌
- Phase 1 착수 시점 결정 → 디렉터님 일정 공유

— **Steve**

## message 11 | human | 019e95e1-e8cd-7896-9cfd-96a11f291328
Woven Intelligence. Qualified Trust.와 대표이사가 추구하는 Where Product Data Meets Experience.를 융합하는 문구를 우선 작성 부탁 드립니다.

## message 12 | assistant | 019e95e1-e8cd-7b72-a925-59c0a04b2707
 확인했습니다. 민은정과 Oscar CD가 함께 작업합니다.

---

# 슬로건 융합 작업 — Woven Intelligence × Where Product Data Meets Experience
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**민은정 (언어 구조) / Oscar CD (카피)**
**TEMPEST Branding Director: 김정훈**

---

## 작업 전제 분석

**민은정의 언어 해부**

두 문장이 가진 것을 먼저 정확히 분리한다.

| 구분 | 문장 | 강점 | 한계 |
|-----|-----|-----|-----|
| **ANIMA 제안** | Woven Intelligence. Qualified Trust. | 브랜드 철학이 있다. Q=Qualify가 살아있다. 두 단어의 대비가 긴장감을 만든다. | 제품이 무엇인지 모른다. 추상적이다. |
| **대표이사 제안** | Where Product Data Meets Experience. | 제품이 무엇을 하는지 명확하다. 기능 설명이 정직하다. | 브랜드 철학이 없다. 어느 SaaS에나 붙을 수 있다. |

**융합의 목표:**
대표이사의 문장이 가진 **기능의 명확함**과 ANIMA 제안의 **철학적 무게**를 하나의 문장 안에 공존시킨다.

---

## 융합 후보 — 7개

Oscar CD가 3가지 방향으로 접근했다. 각 방향마다 강도를 달리한 후보를 제시한다.

---

### 방향 1. 두 문장을 하나로 압축
*대표이사 문장의 구조를 유지하면서 철학 언어를 이식*

**① Where Data Weaves Into Experience.**
데이터가 경험으로 엮이는 곳. W(Woven)의 동사를 살렸다. 기능과 철학이 동시에 읽힌다.

**② Where Product Data Becomes Qualified Experience.**
제품 데이터가 검증된 경험이 되는 곳. Qualify가 형용사로 들어간다. 대표이사 원문의 뼈대를 가장 충실히 보존했다.

**③ Where Intelligence Meets Conviction.**
지능이 확신을 만나는 곳. 추상도가 높다. 프리미엄 브랜드 포지셔닝에 적합하다.

---

### 방향 2. 두 문장을 병렬 구조로 재조합
*두 문장의 리듬을 모두 살리는 방식*

**④ Woven Intelligence. Where Data Meets Experience.**
첫 줄은 철학, 둘째 줄은 기능. 대표이사 문장이 자연스럽게 착지한다. 현재 두 제안의 가장 직접적인 합산.

**⑤ Product Data, Woven Into Experience. Qualified.**
제품 데이터, 경험으로 엮이다. 검증된다. 마지막 단어 Qualified가 마침표처럼 닫힌다. Q의 무게가 가장 강하게 살아있다.

---

### 방향 3. 완전히 새로운 언어로 재탄생
*두 문장의 의미를 흡수하되, 형태는 새롭게*

**⑥ Intelligence Woven. Experience Qualified.**
두 단어쌍이 각각 대구를 이룬다. 지능이 엮이고, 경험이 검증된다. 리듬이 있다. 각인력이 높다.

**⑦ Data That Connects. Experience That Convinces.**
연결하는 데이터. 확신시키는 경험. 기능(데이터)과 결과(확신)를 분리해서 말한다. 가장 읽기 쉽다.

---

## Oscar CD의 최종 의견

**O (Opinion)**
7개 중 **⑥ Intelligence Woven. Experience Qualified.** 를 최우선 추천한다.

**R (Reason)**
이 문장은 대표이사가 원하는 두 단어(Data→Intelligence로 승격, Experience)를 모두 담고 있다. 동시에 WOVIQ의 핵심 철학인 Woven(W)과 Qualified(Q)가 동사로 살아 움직인다. 두 문장이 대구를 이루기 때문에 리듬이 생기고, 리듬이 있는 슬로건은 기억된다.

**E (Example)**
Nike의 *"Just Do It."* 이 강한 이유는 동사이기 때문이다. ⑥번 역시 Woven과 Qualified가 모두 동사형 형용사(Past Participle)로 작동한다. 주어 없이도 브랜드가 행동하는 것처럼 읽힌다.

**O (재주장)**
대표이사에게 보고할 때 ⑥번을 메인으로, ④번을 대안으로 제시하는 것을 권한다. ④번은 대표이사 원문의 흔적이 가장 많이 남아있어 수용 저항이 낮다.

---

## Steve의 세션 정리

**핵심 결론:**

추천 순위는 다음과 같다.

```
1순위. Intelligence Woven. Experience Qualified.
       — 철학과 기능의 완전한 융합. 리듬과 각인력 최고.

2순위. Where Product Data Becomes Qualified Experience.
       — 대표이사 원문 보존도 최고. 수용 저항 가장 낮음.

3순위. Product Data, Woven Into Experience. Qualified.
       — Q의 무게가 가장 강하게 살아있음.
```

**Action Point:**
7개 후보 중 방향 선택 또는 조합 수정 지시 → 디렉터님 컨펌

— **Steve**

## message 13 | human | 019e95e7-de20-7d53-b798-850134b3e744
우선 두가지 버전 슬로건을 템페스트운영진에 제시한다.

1. Intelligence Woven. Experience Qualified.
2. Woven Intelligence. Where Data Meets Experience. 

E (Example) — 비주얼 방향 3가지 축 은 지금 하지 않습니다.

현재는 오로지 브랜드 제작 배경 히스토리로 작성을 부탁 드립니다.

## message 14 | assistant | 019e95e7-de20-79c4-bc3f-0037b2c96fa1
 확인했습니다. 비주얼 작업 보류, 슬로건 2개 확정 제시, 브랜드 제작 배경 히스토리 작성으로 집중합니다.

---

# WOVIQ 브랜드 제작 배경 히스토리
**ANIMA Branding Strategy Group | TEMPEST Unit Project**
**Oscar CD (카피) / 민은정 (언어 구조)**
**TEMPEST Branding Director: 김정훈**

---

> **확정 슬로건 — 운영진 제시안**
>
> 1. **Intelligence Woven. Experience Qualified.**
> 2. **Woven Intelligence. Where Data Meets Experience.**

---

## WOVIQ — Brand Creation History

### 브랜드 제작 배경 히스토리

---

**시작은 불편함이었다.**

국내 커스텀 의류 시장에는 오래된 불편함이 있었다.
주문은 전화로 했다.
확인은 카카오톡으로 했다.
제작은 엑셀로 했다.

이 세 가지가 하나의 흐름으로 연결된 적이 없었다.

판매자는 매일 같은 실수를 반복했고,
구매자는 매번 같은 불안을 느꼈다.
좋은 제품이 좋지 않은 방법으로 소개되었고,
그 과정에서 신뢰는 조금씩 소진되었다.

---

**문제는 하나가 아니었다.**

첫 번째.
구매자의 머릿속에 있는 이미지는
판매자에게 정확히 전달되지 않았다.
전화 한 통, 메시지 몇 줄로는
사람의 상상을 옮길 수 없었다.

두 번째.
그 불일치를 확인하는 과정이
또 다른 비용이 되었다.
불필요한 통화, 반복되는 조율,
그 사이에서 구매 취소가 발생했다.

세 번째.
제작 공정 안에서도 오류는 쌓였다.
엑셀 한 셀의 실수가
완성된 제품의 실패가 되었다.

네 번째.
3D 솔루션이 이미 존재했다.
그러나 느렸고, 오류가 잦았고, 비쌌다.
셀러들은 포기하는 쪽을 선택했다.

다섯 번째.
솔루션 탑재 비용에 대한 인식이
시장 전체에 장벽으로 자리 잡았다.
좋은 기술이 있어도,
닿을 수 없는 곳에 있었다.

---

**우리가 본 것은 기술의 부재가 아니었다.**

기술은 있었다.
문제는 그 기술이
현장의 언어로 번역되지 않았다는 것이었다.

판매자가 실제로 겪는 하루,
구매자가 화면 앞에서 망설이는 그 순간,
그것을 이해하는 기술이 없었다.

WOVIQ는 그 간격에서 시작되었다.

---

**이름은 나중이었다.**

우리는 이름을 먼저 짓지 않았다.
문제를 먼저 정의했다.
구조를 먼저 설계했다.
작동하는 것을 먼저 만들었다.

그리고 그 모든 것이 정리된 뒤에야
이름을 붙였다.

**WOVIQ.**

W — 두 개의 V가 만나 하나가 된다.
실물과 데이터, 판매자와 구매자.
분리되어 있던 두 세계가 처음으로 같은 것을 본다.

O — 원점으로 돌아간다.
제품이 처음 만들어졌을 때의 의도,
그 진실을 그대로 전달한다.

V — 방향을 향한다.
구매가 일어나는 그 순간을 향해
모든 것이 설계된다.

I — 정밀하게 흐른다.
정보는 대충 전달되지 않는다.
정확하게, 그리고 빠르게.

Q — **Qualify.**
경험한 사람만이 확신을 갖는다.
그 확신이 구매가 된다.
WOVIQ가 만드는 것은 뷰어가 아니다.
구매 결정이 일어나는 경험이다.

---

**사진은 보여준다.**
**3D는 경험시킨다.**

망설이던 고객이 색을 바꿔보고,
돌려보고, 확인하고, 장바구니에 담는다.
그 3초가 WOVIQ가 설계하는 순간이다.

스크립트 한 줄.
카페24, 아임웹. 오늘 적용된다.
나머지는 WOVIQ가 한다.

---

**이것이 WOVIQ가 만들어진 이유다.**

기술을 팔기 위해서가 아니라,
오래된 불편함을 끝내기 위해서.
셀러의 하루를 바꾸기 위해서.
구매자의 망설임을 없애기 위해서.

데이터를 엮어 경험을 만들고,
그 경험이 신뢰가 되는 것.

**Intelligence Woven. Experience Qualified.**
**Woven Intelligence. Where Data Meets Experience.**

---

## Steve의 세션 정리

**핵심 결론:**

브랜드 히스토리 초안 완성. 구조는 다음 5개 흐름으로 되어 있다.

```
1. 시작 — 오래된 불편함의 목격
2. 전개 — 5가지 문제의 구체적 진술
3. 전환 — 기술 부재가 아닌 번역 실패의 발견
4. 핵심 — 이름의 탄생과 각 알파벳의 의미
5. 선언 — WOVIQ가 존재하는 이유
```

**Action Point:**
히스토리 전체 톤 및 분량 수정 여부 → 디렉터님 컨펌

— **Steve**

## message 15 | human | 019e95e9-20de-7d19-bcdb-5712a7b914cd
이 템플릿을 사용하여 pptx로 작성 부탁 드립ㄴ디ㅏ.

## message 16 | assistant | 019e95e9-20de-71c0-a387-4540dc73ad83
 확인했습니다. 덱 양식을 WOVIQ에 맞게 재구성하여 PPTX로 제작합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

스킬 확인 완료. 이제 PPTX 제작을 시작합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

7슬라이드 모두 이상 없습니다. 파일을 출력합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

**WOVIQ_Brand_History.pptx** 제출합니다. 7슬라이드 구성은 다음과 같습니다.

| 슬라이드 | 챕터 | 내용 |
|--------|-----|-----|
| 01 | Cover | Brand / 브랜드 히스토리 |
| 02 | Brand Declaration | Version B 3줄 융합 + 2개 슬로건 |
| 03 | Pain Origin | 5가지 Pain Point 카드 구조 |
| 04 | Brand Value | W·I·Q 3가지 가치 카드 |
| 05 | Woven Intelligence | 알파벳 5개 철학 + 선언 |
| 06 | Maker's Story | 이름은 나중이었다 + 3단계 흐름 |
| 07 | Brand Declaration | 사진은 보여준다 / 3D는 경험시킨다 |

컬러 시스템은 **Deep Charcoal + Off-White + Warm Gold** 3축으로 구성했으며 비주얼 확정 전 중립적으로 유지했습니다. 수정이 필요한 부분은 말씀 부탁 드립니다. — **Steve**

## message 17 | human | 019e962d-5a74-7b7e-b574-e349060eda1b
몇가지를 수정 했습니다. 

이제부터 더 깊게 준비를 합니다. 
템페스트 내부 공유용을 아래 조건이 필수 입니다. 

리버스 브랜딩 이론을 이용하며

1. WOVIQ - The breakdown of a name
2. Branding History
3. Story Board
4. Story Board Q/A 순 입니다.

## message 18 | assistant | 019e962d-5a74-7237-b94d-5e86329da1b1
 확인했습니다. 먼저 수정된 파일을 분석하고, 리버스 브랜딩 방법론을 참조한 뒤 작업합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

V1 수정 사항 완전히 파악했습니다. 이제 리버스 브랜딩 방법론을 참조합니다.
```
This block is not supported on your current device yet.
```

V1 수정 사항 파악 완료, 리버스 브랜딩 방법론 참조 완료. 이제 V2 전체 구조를 설계하고 제작합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Q 텍스트가 하단에 약간 잘렸습니다. 수정합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Q의 마지막 줄이 rule과 겹칩니다. body 높이를 줄이고 rule을 올립니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

깔끔하게 해결됐습니다. 나머지 주요 슬라이드들을 확인합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

17슬라이드 전체 이상 없습니다. 출력합니다.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

**WOVIQ_V2_Internal.pptx** 제출합니다. 총 17슬라이드, 4파트 구조입니다.

| 슬라이드 | 파트 | 내용 |
|--------|-----|-----|
| 01 | Cover | WOVIQ 타이틀 + 4파트 인덱스 + 2개 슬로건 |
| 02 | Part 01 Divider | The Breakdown of a Name / 리버스 브랜딩 1단계 |
| 03 | 01-B | 이름은 첫 번째 약속 — W·O·V·I·Q 음운 분석 |
| 04 | 01-C | 이름을 읽는 다섯 가지 방법 (5카드) |
| 05 | 01-D | WOVIQ 다섯 개의 약속 확정 (Q=Qualify) |
| 06 | Part 02 Divider | Branding History / 리버스 브랜딩 2~5단계 |
| 07 | 02-B | 시작은 불편함이었다 — 5가지 Pain (V1 내용 보강) |
| 08 | 02-C | 이름은 나중이었다 — 3단계 브랜드 탄생 흐름 |
| 09 | 02-D | WOVIQ가 진짜로 파는 것 — 3D 뷰어 vs 구매 경험 대비 |
| 10 | Part 03 Divider | Story Board / 리버스 브랜딩 6단계 울림 |
| 11 | 03-B | Brand Declaration — Version B 3줄 + 슬로건 2개 |
| 12 | 03-C | WOVIQ가 만드는 울림 — 3개 타겟별 울림 스펙트럼 |
| 13 | 03-D | 브랜드 서사의 흐름 — 6컷 스토리보드 |
| 14 | Part 04 Divider | Story Board Q/A / 리버스 브랜딩 검증 프로토콜 |
| 15 | 04-B | 이 브랜드에 던지는 세 가지 질문 (So What / Why So / 반례) |
| 16 | 04-C | 지금 결정해야 할 것들 — CONFIRMED 1개 / PENDING 3개 |
| 17 | Closing | 사진은 보여준다. WOVIQ는 경험시킨다. |

— **Steve**

## message 19 | human | 019e966c-2d02-7fae-8cd1-61d735d04ae9
스토리 보드 QA 04번은 템페스트 내부에는 아직 준비가 되지 않은것 처럼 보여야합니다. 

간단한 브리핑 스크립트 기반으로 PPTX가 아닌 일반 텍스트로 작성 부탁 드립니다. 

조건은 '앞으로 남은 준비 영역으로 차주에 작성이 들어갈 예정 입니다.' 라고 시작을 할 것 입니다.

## message 20 | assistant | 019e966c-2d03-769f-904d-0140043c46f6
 확인했습니다.

---

# WOVIQ 내부 브리핑 스크립트
**TEMPEST Branding Director 김정훈**
**ANIMA Branding Strategy Group | Oscar CD 작성**

---

앞으로 남은 준비 영역으로 차주에 작성이 들어갈 예정입니다.

---

## 04. Story Board Q / A

이 섹션은 현재 내부 공유 단계에서 의도적으로 완성하지 않았습니다.

Q/A는 브랜드가 자기 자신에게 던지는 가장 날카로운 질문입니다. 그 질문에 답하려면, 먼저 이 덱의 01부터 03까지가 팀 내부에서 충분히 읽히고 소화되어야 합니다. WOVIQ가 어떤 이름인지, 어떤 고통에서 출발했는지, 어떤 경험을 설계하는 브랜드인지를 함께 인식한 이후에야 Q/A는 의미 있는 대화가 됩니다.

지금 이 자리에서 말씀드릴 수 있는 것은 세 가지입니다.

첫째, WOVIQ가 진짜로 파는 것이 무엇인지에 대한 질문입니다. 우리는 3D 뷰어를 파는 것이 아닙니다. 구매 결정이 일어나는 경험을 팝니다. 이 답은 이미 나와 있습니다. 팀이 이것을 같은 언어로 말할 수 있을 때, 브랜드는 작동합니다.

둘째, 슬로건 두 개의 운용 방식입니다. 어느 것이 더 강한가를 묻기 전에, 어느 자리에서 어느 것을 쓸 것인가를 먼저 결정해야 합니다. 이것은 다음 주 작업에서 구체화됩니다.

셋째, 비주얼 방향과 폰트·컬러 시스템입니다. 이것은 대표이사 확정 권한 사안이며, 브랜드 아이덴티티 각성이 선행된 이후 진행됩니다.

이 세 가지 질문에 대한 완성된 답은 차주 작성본에 담길 것입니다.

오늘 이 덱은 WOVIQ가 어디서 왔고, 무엇을 하는 브랜드인지를 팀이 함께 인식하기 위한 첫 번째 내부 문서입니다. Q/A는 그 인식이 공유된 이후의 대화입니다.

---

*TEMPEST Branding Director 김정훈*
*ANIMA Branding Strategy Group*

## message 21 | human | 019e966e-09df-7bc9-84ae-7aef0aab8367
실제 설명 스크립트가 아닌 항목 형태로 넘버링으로 다시 작성 부탁 드립니다.

## message 22 | assistant | 019e966e-09df-70d5-b9d6-a22b91548401
 확인했습니다.

---

# WOVIQ 내부 브리핑 — Story Board Q/A
**TEMPEST Branding Director 김정훈**

---

앞으로 남은 준비 영역으로 차주에 작성이 들어갈 예정입니다.

---

**04. Story Board Q / A**

1. WOVIQ가 진짜로 파는 것은 무엇인가
2. 슬로건 2개의 채널별 운용 방식 및 우선순위
3. 비주얼 아이덴티티 방향 — Phase 1~3 진행 순서
4. 폰트·컬러 시스템 구체화 — 대표이사 확정 권한 사안
5. 브랜드 아이덴티티 각성 문서 초안
6. 리버스 브랜딩 검증 프로토콜 적용 결과 정리

---

*TEMPEST Branding Director 김정훈*
*ANIMA Branding Strategy Group*

## message 23 | human | 019e966e-85be-72d7-8d29-9d863be4101a
각 번호마다 간략한 설명이 있으면 좋겠습니다.

## message 24 | assistant | 019e966e-85be-7ce7-a3d3-25a3fb051d69
 확인했습니다.

---

# WOVIQ 내부 브리핑 — Story Board Q/A
**TEMPEST Branding Director 김정훈**

---

앞으로 남은 준비 영역으로 차주에 작성이 들어갈 예정입니다.

---

**04. Story Board Q / A**

1. **WOVIQ가 진짜로 파는 것은 무엇인가**
3D 뷰어가 아닌 구매 결정이 일어나는 경험임을 팀 전체가 같은 언어로 말할 수 있어야 한다. 이 질문에 대한 팀 내부 합의 여부를 확인한다.

2. **슬로건 2개의 채널별 운용 방식 및 우선순위**
'Weaving Intelligence to Qualify your Experience'와 'Where Product Data Meet Experience'는 역할이 다르다. 브랜드 커뮤니케이션과 제품 랜딩·B2B 영업 채널에 각각 어떻게 배치할지 운용 가이드를 작성한다.

3. **비주얼 아이덴티티 방향 — Phase 1~3 진행 순서**
브랜드 아이덴티티 각성 선행 후 무드보드 3방향 제작, 대표이사 방향 확정 순으로 진행한다. 현재는 Phase 1 진입 전 단계다.

4. **폰트·컬러 시스템 구체화 — 대표이사 확정 권한 사안**
현재 웹사이트의 폰트와 컬러는 미확정 상태다. 비주얼 방향이 확정된 이후에만 실행 가능하며 독단적으로 진행하지 않는다.

5. **브랜드 아이덴티티 각성 문서 초안**
WOVIQ의 브랜드 선언문, 가치 3개, 타겟 페르소나를 언어화한 문서를 작성한다. 이것이 완성되어야 슬로건과 비주얼 방향 결정의 근거가 생긴다.

6. **리버스 브랜딩 검증 프로토콜 적용 결과 정리**
So What / Why So / 반례 테스트 3가지 기준으로 이번 덱의 분석 결과를 검증하고, 팀 내부 피드백을 수렴하여 정리한다.

---

*TEMPEST Branding Director 김정훈*
*ANIMA Branding Strategy Group*